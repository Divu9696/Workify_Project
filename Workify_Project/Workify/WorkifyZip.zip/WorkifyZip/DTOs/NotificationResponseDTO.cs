using System;

namespace Workify.DTOs;

public class NotificationResponseDTO
{
public string Message { get; set; } = string.Empty;
}
