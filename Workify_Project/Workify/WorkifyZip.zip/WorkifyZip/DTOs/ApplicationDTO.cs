using System;

namespace Workify.DTOs;

public class ApplicationDTO
{
    public int JobSeekerId { get; set; }
    public int JobListingId { get; set; }
}

